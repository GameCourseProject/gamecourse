&lt;?php
use SmartBoards\Core;
use SmartBoards\Module;
use SmartBoards\ModuleLoader;

class CustomNavigation extends Module {
    public function init() {
        $user = Core::getLoggedUser();
        if (($user != null && $user->isAdmin()))
            Core::addNavigation('images/gear.svg', 'Técnico', 'http://tecnico.ulisboa.pt');
    }
}

ModuleLoader::registerModule(array(
    'id' => 'customnav',
    'name' => 'Custom Navigation',
    'version' => '0.1',
    'factory' => function() {
        return new CustomNavigation();
    }
));
