drop table if exists badge_level;
drop table if exists badge_progression;
drop table if exists badge;
drop table if exists badges_config;
